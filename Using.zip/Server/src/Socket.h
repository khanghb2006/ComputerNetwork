#pragma once

void startSocketServer();