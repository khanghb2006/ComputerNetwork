#pragma once

enum class WSDataType {
	KEYLOG, 
	IMAGE, 
	VIDEO, 
	LISTAPP, 
	LISTPROC
};